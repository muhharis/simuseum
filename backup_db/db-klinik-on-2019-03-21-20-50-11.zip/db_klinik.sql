#
# TABLE STRUCTURE FOR: m_barang
#

DROP TABLE IF EXISTS `m_barang`;

CREATE TABLE `m_barang` (
  `kode_barang` varchar(10) NOT NULL,
  `nm_barang` varchar(30) NOT NULL,
  `grup_brg_id` varchar(10) NOT NULL,
  `kategori_brg_id` varchar(10) NOT NULL,
  `satuan_id` varchar(10) NOT NULL,
  `spesifikasi` text NOT NULL,
  `foto_brg` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kode_barang`),
  KEY `grup_brg_id` (`grup_brg_id`),
  KEY `kategori_brg_id` (`kategori_brg_id`),
  KEY `satuan_id` (`satuan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_barang` (`kode_barang`, `nm_barang`, `grup_brg_id`, `kategori_brg_id`, `satuan_id`, `spesifikasi`, `foto_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('1445', 'INDOMIE', '120', 'KTB01', 'SB03', 'WE', 'Tulips.jpg', '2019-03-15 03:08:15', NULL, 'Aktif');
INSERT INTO `m_barang` (`kode_barang`, `nm_barang`, `grup_brg_id`, `kategori_brg_id`, `satuan_id`, `spesifikasi`, `foto_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('sadsad', 'sadsad', '120', '9', 'dasd', 'sadsad', 'Koala.jpg', NULL, NULL, 'Tidak Aktif');
INSERT INTO `m_barang` (`kode_barang`, `nm_barang`, `grup_brg_id`, `kategori_brg_id`, `satuan_id`, `spesifikasi`, `foto_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('sadsad1234', 'asdsa2134', '120', '9', 'dasd', 'sadsad', 'KM.png', NULL, NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: m_hadiah
#

DROP TABLE IF EXISTS `m_hadiah`;

CREATE TABLE `m_hadiah` (
  `id_hadiah` varchar(10) NOT NULL,
  `hadiah` varchar(50) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id_hadiah`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_hadiah` (`id_hadiah`, `hadiah`, `create_at`, `update_at`, `is_aktif`) VALUES ('09', 'PIRING', '2019-03-17 23:05:51', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: m_pasien
#

DROP TABLE IF EXISTS `m_pasien`;

CREATE TABLE `m_pasien` (
  `kode_pasien` varchar(10) NOT NULL,
  `no_rek_medik` varchar(60) NOT NULL,
  `nm_pasien` varchar(90) NOT NULL,
  `gender_id` varchar(10) NOT NULL,
  `tgl_lahir` date NOT NULL,
  `tmpt_lahir` varchar(50) NOT NULL,
  `no_identitas` varchar(30) NOT NULL,
  `no_telp` varchar(20) NOT NULL,
  `gol_darah` varchar(2) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `kd_kel` varchar(10) NOT NULL,
  `agama_id` varchar(10) NOT NULL,
  `pend_id` varchar(10) NOT NULL,
  `id_pekerjaan` varchar(10) NOT NULL,
  `id_sk` varchar(10) NOT NULL,
  `foto_pasien` varchar(255) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kode_pasien`),
  KEY `kelurahanl_id` (`kd_kel`),
  KEY `agama_id` (`agama_id`),
  KEY `pend_id` (`pend_id`),
  KEY `pekerjaan_id` (`id_pekerjaan`),
  KEY `gender_id` (`gender_id`),
  KEY `sk_id` (`id_sk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: m_pelaksana
#

DROP TABLE IF EXISTS `m_pelaksana`;

CREATE TABLE `m_pelaksana` (
  `kode_pelaksana` varchar(10) NOT NULL,
  `peran_pelaksana_id` varchar(10) NOT NULL,
  `nama_pelaksana` varchar(90) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kode_pelaksana`),
  KEY `peran_pelaksana_id` (`peran_pelaksana_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_pelaksana` (`kode_pelaksana`, `peran_pelaksana_id`, `nama_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('oop', '45', 'o', NULL, NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: m_pemasok
#

DROP TABLE IF EXISTS `m_pemasok`;

CREATE TABLE `m_pemasok` (
  `kode_pemasok` varchar(10) NOT NULL,
  `nm_pemasok` varchar(90) NOT NULL,
  `no_ktp` varchar(30) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `kota` varchar(200) NOT NULL,
  `telp` varchar(15) NOT NULL,
  `foto_pemasok` varchar(255) NOT NULL,
  `ket` varchar(100) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kode_pemasok`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_pemasok` (`kode_pemasok`, `nm_pemasok`, `no_ktp`, `alamat`, `kota`, `telp`, `foto_pemasok`, `ket`, `create_at`, `update_at`, `is_aktif`) VALUES ('PEMASOK01', 'Ultramen', '123', 'Sunagakure', 'Bakpao', '01293', '', 'asdfghjkl', '2019-03-13 01:57:31', '2019-03-13 12:14:35', 'Aktif');


#
# TABLE STRUCTURE FOR: m_tindakan
#

DROP TABLE IF EXISTS `m_tindakan`;

CREATE TABLE `m_tindakan` (
  `kode_tindakan` varchar(10) NOT NULL,
  `grup_tindakan_id` varchar(10) NOT NULL,
  `tindakan` varchar(100) NOT NULL,
  `s_pelaksana` varchar(10) NOT NULL DEFAULT '1',
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kode_tindakan`),
  KEY `grup_tindakan_id` (`grup_tindakan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `m_tindakan` (`kode_tindakan`, `grup_tindakan_id`, `tindakan`, `s_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('098', 'GT2', 'kulit', 'Ya', '2019-03-13 23:42:13', NULL, 'Aktif');
INSERT INTO `m_tindakan` (`kode_tindakan`, `grup_tindakan_id`, `tindakan`, `s_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('576', 'GT5', 'oio', 'Ya', '2019-03-16 02:55:36', NULL, 'Tidak Aktif');
INSERT INTO `m_tindakan` (`kode_tindakan`, `grup_tindakan_id`, `tindakan`, `s_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('TDT01', 'GT3', 'Lulur dan Masker', 'Ya', NULL, '2019-03-13 23:42:28', 'Aktif');
INSERT INTO `m_tindakan` (`kode_tindakan`, `grup_tindakan_id`, `tindakan`, `s_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('TDT02', 'GT3', 'Akupuntur Betis', 'Ya', NULL, '2019-03-13 23:42:40', 'Aktif');


#
# TABLE STRUCTURE FOR: r_agama
#

DROP TABLE IF EXISTS `r_agama`;

CREATE TABLE `r_agama` (
  `agama_id` varchar(10) NOT NULL,
  `agama` varchar(20) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`agama_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_agama` (`agama_id`, `agama`, `create_at`, `update_at`, `is_aktif`) VALUES ('0123', 'ISLAMasdsad', '2019-03-13 02:34:33', '2019-03-13 02:34:46', 'Aktif');
INSERT INTO `r_agama` (`agama_id`, `agama`, `create_at`, `update_at`, `is_aktif`) VALUES ('dsfgh', 'df', '2019-03-13 02:47:47', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: r_bank
#

DROP TABLE IF EXISTS `r_bank`;

CREATE TABLE `r_bank` (
  `bank_id` varchar(10) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('10', 'BNI SYARIAH', NULL, '2019-03-14 01:26:17', 'Aktif');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('11', 'BANK JATENG', NULL, '2019-03-14 01:26:25', 'Aktif');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('12', 'LINK', NULL, NULL, '1');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('123', 'WERE', NULL, NULL, '1');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('13', 'Britama', NULL, NULL, '1');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('3', 'BNI', NULL, NULL, '1');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('78', 'BMI', NULL, NULL, '1');
INSERT INTO `r_bank` (`bank_id`, `bank`, `create_at`, `update_at`, `is_aktif`) VALUES ('9', 'BSM', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: r_gender
#

DROP TABLE IF EXISTS `r_gender`;

CREATE TABLE `r_gender` (
  `id_gender` varchar(10) NOT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_gender`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_grup_barang
#

DROP TABLE IF EXISTS `r_grup_barang`;

CREATE TABLE `r_grup_barang` (
  `grup_brg_id` varchar(10) NOT NULL,
  `nm_grup_brg` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`grup_brg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_grup_barang` (`grup_brg_id`, `nm_grup_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('120', 'SABUN', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: r_grup_tindakan
#

DROP TABLE IF EXISTS `r_grup_tindakan`;

CREATE TABLE `r_grup_tindakan` (
  `grup_tindakan_id` varchar(10) NOT NULL,
  `grup_tindakan` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`grup_tindakan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_grup_tindakan` (`grup_tindakan_id`, `grup_tindakan`, `create_at`, `update_at`, `is_aktif`) VALUES ('GT1', 'ADMINISTRASI', NULL, NULL, '1');
INSERT INTO `r_grup_tindakan` (`grup_tindakan_id`, `grup_tindakan`, `create_at`, `update_at`, `is_aktif`) VALUES ('GT2', 'TINDAKAN', NULL, NULL, '1');
INSERT INTO `r_grup_tindakan` (`grup_tindakan_id`, `grup_tindakan`, `create_at`, `update_at`, `is_aktif`) VALUES ('GT3', 'KONSULTASI DOKTER', NULL, NULL, '1');
INSERT INTO `r_grup_tindakan` (`grup_tindakan_id`, `grup_tindakan`, `create_at`, `update_at`, `is_aktif`) VALUES ('GT5', 'PEMERIKSAAN DOKTER', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: r_harga_jual
#

DROP TABLE IF EXISTS `r_harga_jual`;

CREATE TABLE `r_harga_jual` (
  `harga_jual_id` varchar(10) NOT NULL,
  `kode_barang` varchar(20) NOT NULL,
  `kelas_id` varchar(10) NOT NULL,
  `harga_jual` int(10) NOT NULL,
  `disc_persen` decimal(4,0) NOT NULL,
  `disc_rupiah` int(10) NOT NULL,
  `tgl_berlaku` datetime NOT NULL,
  `ket` text NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`harga_jual_id`),
  KEY `barang_id` (`kode_barang`),
  KEY `kelas_id` (`kelas_id`),
  KEY `barang_id_2` (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_jenis_kunjungan
#

DROP TABLE IF EXISTS `r_jenis_kunjungan`;

CREATE TABLE `r_jenis_kunjungan` (
  `Jenis_kunjungan_id` varchar(10) NOT NULL,
  `jenis_kunjungan` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`Jenis_kunjungan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_jenis_pengeluaran
#

DROP TABLE IF EXISTS `r_jenis_pengeluaran`;

CREATE TABLE `r_jenis_pengeluaran` (
  `id` varchar(10) NOT NULL,
  `jenis_pengeluaran` varchar(200) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_kab
#

DROP TABLE IF EXISTS `r_kab`;

CREATE TABLE `r_kab` (
  `kd_prop` varchar(10) NOT NULL,
  `kd_kab` varchar(10) NOT NULL,
  `nm_kab` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kd_kab`),
  KEY `kd_prop` (`kd_prop`,`kd_kab`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '0', 'JAKARTA', '2019-03-14 00:28:41', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '1', 'CILACAP', '2019-03-14 00:28:39', '2019-03-14 00:29:13');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '10', 'KLATEN', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '11', 'SUKOHARJO', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '12', 'WONOGIRI', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('11', '1234', 'JAKARTA', '2019-03-14 00:28:46', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '12345', 'lampung', '2019-03-14 00:28:46', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '13', 'KARANGANYAR', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '14', 'SRAGEN', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '15', 'GROBOGAN', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '16', 'BLORA', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '17', 'REMBANG', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '18', 'PATI', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '19', 'KUDUS', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '2', 'BANYUMAS', '2019-03-14 00:28:39', '2019-03-14 00:29:13');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '20', 'JEPARA', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '21', 'DEMAK', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '22', 'SEMARANG', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '23', 'TEMANGGUNG', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '24', 'KENDAL', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '25', 'BATANG', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '26', 'PEKALONGAN', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '27', 'PEMALANG', '2019-03-14 00:28:41', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '28', 'TEGAL', '2019-03-14 00:28:41', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '29', 'BREBES', '2019-03-14 00:28:41', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '3', 'PURBALINGGA', '2019-03-14 00:28:39', '2019-03-14 00:29:13');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '4', 'BANJARNEGARA', '2019-03-14 00:28:39', '2019-03-14 00:29:13');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '5', 'KEBUMEN', '2019-03-14 00:28:40', '2019-03-14 00:29:13');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '6', 'PURWOREJO', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('20', '65535', 'SINGKAWANG', '2019-03-14 00:28:47', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '7', 'WONOSOBO', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '71', 'KOTA MAGELANG', '2019-03-14 00:28:41', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '72', 'SURAKARTA', '2019-03-14 00:28:41', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '73', 'SALATIGA', '2019-03-14 00:28:41', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '74', 'SEMARANG', '2019-03-14 00:28:41', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '75', 'PEKALONGAN', '2019-03-14 00:28:41', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '76', 'TEGAL', '2019-03-14 00:28:41', '2019-03-14 00:29:15');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '8', 'KAB. MAGELANG', '2019-03-14 00:28:40', '2019-03-14 00:29:14');
INSERT INTO `r_kab` (`kd_prop`, `kd_kab`, `nm_kab`, `create_at`, `update_at`) VALUES ('13', '9', 'BOYOLALI', '2019-03-14 00:28:40', '2019-03-14 00:29:14');


#
# TABLE STRUCTURE FOR: r_kategori_brg
#

DROP TABLE IF EXISTS `r_kategori_brg`;

CREATE TABLE `r_kategori_brg` (
  `kategori_brg_id` varchar(10) NOT NULL,
  `kategori_brg` varchar(20) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kategori_brg_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_kategori_brg` (`kategori_brg_id`, `kategori_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('KTB01', 'BEBAS', '2019-03-13 23:49:41', NULL, 'Aktif');
INSERT INTO `r_kategori_brg` (`kategori_brg_id`, `kategori_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('KTB02', 'BEBAS TERBATAS', '2019-03-13 23:50:07', NULL, 'Aktif');
INSERT INTO `r_kategori_brg` (`kategori_brg_id`, `kategori_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('KTB03', 'OBAT KERAS', '2019-03-13 23:50:22', NULL, 'Aktif');
INSERT INTO `r_kategori_brg` (`kategori_brg_id`, `kategori_brg`, `create_at`, `update_at`, `is_aktif`) VALUES ('KTB04', 'Luminous cream', '2019-03-13 23:50:41', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: r_kec
#

DROP TABLE IF EXISTS `r_kec`;

CREATE TABLE `r_kec` (
  `kd_kab` varchar(10) NOT NULL,
  `kd_kec` varchar(10) NOT NULL,
  `nm_kec` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL,
  PRIMARY KEY (`kd_kec`),
  KEY `kd_kab` (`kd_kab`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '1', 'Sukolilo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '10', 'Kayen', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('41', '100', '34', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('5', '101', 'PETANAHAN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('22', '102', 'GAYAMSARI', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('42', '103', 'surabaya', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('43', '104', 'NUSA DUA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '105', 'BAE', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '106', 'WONOSALAM', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('44', '107', 'AUR BURIGO TIGO BALEH', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '108', 'GAJAH', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '11', 'Tambakromo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '12', 'Winong', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '13', 'Pucakwangi', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '14', 'Jaken', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '15', 'Batangan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '16', 'Juwana', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '17', 'Jakenan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '18', 'Pati', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '19', 'Gabus', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '2', 'Margorejo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '20', 'Gembong', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '21', 'Tlogowungu', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '22', 'Wedarijaksa', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '23', 'Margoyoso', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '24', 'Gunungwungkal', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '25', 'Cluwak', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '26', 'Tayu', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '27', 'Dukuhseti', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('18', '28', 'Trangkil', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '29', 'Kaliwungu', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '3', 'Kudus', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '30', 'Jati', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '31', 'Undaan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '32', 'Mejobo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '33', 'Jekulo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '34', 'Bae', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '35', 'Gebog', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('19', '36', 'Dawe', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '37', 'Kedung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '38', 'Pecangaan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '39', 'Welahan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '4', 'Mayong', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '40', 'Batealit', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '41', 'Jepara', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '42', 'Mlonggo', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '43', 'Bangsri', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '44', 'Keling', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '45', 'Karimun Jawa', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '46', 'Tahunan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '47', 'Nalumsari', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '48', 'Kalinyamatan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '49', 'Kembang', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '5', 'Mranggen', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '50', 'Karangawen', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '51', 'Guntur', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '52', 'Sayung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '53', 'Karangtengah', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '54', 'Wonosalam', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '55', 'Dempet', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '56', 'Gajah', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '57', 'Karanganyar', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '58', 'Mijen', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '59', 'Demak', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '6', 'Bonang', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '60', 'Wedung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('21', '61', 'Kebonagung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '62', 'batealit', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '63', 'DONOROJO', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '64', 'PAKISAJI', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '65', 'KRASAK', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '66', 'karimun jawa', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('17', '67', 'kragan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '68', 'KEDUNG', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '69', 'KWASEN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('37', '7', 'JAKARTA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '70', 'dawe', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('16', '71', 'blora', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('36', '72', 'JAKARTA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('2', '73', 'BATURADEN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '74', 'PANGURAGAN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('25', '75', 'BATANG', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '76', 'PATI', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('26', '77', 'BATEALIT', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '78', 'bonang', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '79', 'rembang', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '8', 'DEMAAN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '80', 'jakenan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '81', 'kudus', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('33', '82', 'semarang', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '83', 'KUDUS', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '84', 'BLORA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '85', 'JAKARTA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('34', '86', 'PEKALONGAN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('22', '87', 'SEMARANG', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '88', 'SEMARANG', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '89', 'jepara', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('23', '9', 'temanggung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('15', '90', 'pulokulon', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '91', 'DEMAK', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('38', '92', 'lampung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('17', '93', 'SARANG', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '94', 'kalimantan', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('39', '95', 'SINGKAWANG UTARA', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('40', '96', 'lampung', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('17', '97', '33', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('15', '98', 'NGARINGAN', NULL, NULL);
INSERT INTO `r_kec` (`kd_kab`, `kd_kec`, `nm_kec`, `create_at`, `update_at`) VALUES ('20', '99', 'TEGAL', NULL, NULL);


#
# TABLE STRUCTURE FOR: r_kel
#

DROP TABLE IF EXISTS `r_kel`;

CREATE TABLE `r_kel` (
  `kd_kec` varchar(10) NOT NULL,
  `kd_kel` varchar(10) NOT NULL,
  `nm_kel` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kd_kel`),
  KEY `kd_kec` (`kd_kec`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2001', 'Prawoto', '2019-03-14 00:56:26', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2002', 'Pakem', '2019-03-14 00:55:57', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2003', 'Wegil', '2019-03-14 00:56:13', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2004', 'Kuwawur', '2019-03-14 00:56:14', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2005', 'Baleadi', '2019-03-14 00:56:15', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2006', 'Wotan', '2019-03-14 00:56:16', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2007', 'Kedungwinong', '2019-03-14 00:56:16', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2008', 'Porangparing', '2019-03-14 00:56:17', '2019-03-14 00:58:14');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2009', 'Sukolilo', '2019-03-14 00:56:17', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2010', 'Baturejo', '2019-03-14 00:56:18', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2011', 'Gadudero', '2019-03-14 00:55:58', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2012', 'Sumbersoko', '2019-03-14 00:56:01', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2013', 'Tompegunung', '2019-03-14 00:56:03', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2014', 'Kedumulyo', '2019-03-14 00:56:03', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2015', 'Klakahsiyah', '2019-03-14 00:56:04', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('1', '2016', 'Cengkalsewu', '2019-03-14 00:56:04', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('2', '8', 'Jimbaran', '2019-03-14 00:56:05', '2019-03-14 00:58:15');
INSERT INTO `r_kel` (`kd_kec`, `kd_kel`, `nm_kel`, `create_at`, `update_at`) VALUES ('2', '9', 'Durensawit', '2019-03-14 00:56:09', '2019-03-14 00:58:15');


#
# TABLE STRUCTURE FOR: r_kelas
#

DROP TABLE IF EXISTS `r_kelas`;

CREATE TABLE `r_kelas` (
  `kelas_id` varchar(10) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kelas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_kelas` (`kelas_id`, `kelas`, `create_at`, `update_at`, `is_aktif`) VALUES ('KLS01', 'UMUM', NULL, NULL, '1');
INSERT INTO `r_kelas` (`kelas_id`, `kelas`, `create_at`, `update_at`, `is_aktif`) VALUES ('KLS02', 'MEMBER', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: r_kurir
#

DROP TABLE IF EXISTS `r_kurir`;

CREATE TABLE `r_kurir` (
  `kurir_id` varchar(10) NOT NULL,
  `kurir` varchar(50) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`kurir_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_pekerjaan
#

DROP TABLE IF EXISTS `r_pekerjaan`;

CREATE TABLE `r_pekerjaan` (
  `id_pekerjaan` varchar(10) NOT NULL,
  `pekerjaan` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_pekerjaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: r_pend
#

DROP TABLE IF EXISTS `r_pend`;

CREATE TABLE `r_pend` (
  `pend_id` varchar(10) NOT NULL,
  `pendidikan` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`pend_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_pend` (`pend_id`, `pendidikan`, `create_at`, `update_at`, `is_aktif`) VALUES ('PEND01', 'SD', '2019-03-14 01:23:55', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: r_peran_pelaksana
#

DROP TABLE IF EXISTS `r_peran_pelaksana`;

CREATE TABLE `r_peran_pelaksana` (
  `peran_pelaksana_id` varchar(10) NOT NULL,
  `peran_pelaksana` varchar(50) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`peran_pelaksana_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_peran_pelaksana` (`peran_pelaksana_id`, `peran_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('DT', 'DOKTER', '2019-03-14 01:05:47', NULL, 'Aktif');
INSERT INTO `r_peran_pelaksana` (`peran_pelaksana_id`, `peran_pelaksana`, `create_at`, `update_at`, `is_aktif`) VALUES ('DT02', 'AKUPUNTUR', '2019-03-14 01:06:05', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: r_prop
#

DROP TABLE IF EXISTS `r_prop`;

CREATE TABLE `r_prop` (
  `kd_prop` varchar(10) NOT NULL,
  `nm_prop` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kd_prop`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('11', 'D.I. ACEH', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('12', 'SUMATERA UTARA', '2019-03-14 00:27:09', '2019-03-14 00:27:18');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('13', 'SUMATERA BARAT', '2019-03-14 00:27:09', '2019-03-14 00:27:18');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('14', 'RIAU', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('15', 'JAMBI', '2019-03-14 00:27:10', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('16', 'SUMATERA SELATAN', '2019-03-14 00:27:09', '2019-03-14 00:27:18');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('17', 'BENGKULU', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('18', 'LAMPUNG', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('19', 'KEP.BANGKA BELITUNG', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('21', 'KEP.RIAU', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('255', 'JAWA BARAT', '2019-03-14 00:27:10', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('31', 'DKI JAKARTA', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('32', 'JAWA BARAT', '2019-03-14 00:27:10', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('33', 'JAWA TENGAH', '2019-03-14 00:27:10', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('34', 'D.I. YOGYAKARTA', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('35', 'JAWA TIMUR', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('36', 'BANTEN', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('51', 'BALI', '2019-03-14 00:27:11', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('52', 'NUSA TENGGARA BARAT', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('53', 'NUSA TENGGARA TIMUR', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('61', 'KALIMANTAN BARAT', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('62', 'KALIMANTAN TENGAH', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('63', 'KALIMANTAN SELATAN', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('64', 'KALIMANTAN TIMUR', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('71', 'SULAWESI UTARA', '2019-03-14 00:27:09', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('72', 'SULAWESI TENGAH', '2019-03-14 00:27:09', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('73', 'SULAWESI SELATAN', '2019-03-14 00:27:09', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('74', 'SULAWESI TENGGARA', '2019-03-14 00:27:09', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('75', 'GORONTALO', '2019-03-14 00:27:10', '2019-03-14 00:27:20');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('76', 'SULAWESI BARAT', '2019-03-14 00:27:09', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('81', 'MALUKU', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('82', 'MALUKU UTARA', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('9', 'po', '2019-03-14 00:27:10', '2019-03-14 00:27:19');
INSERT INTO `r_prop` (`kd_prop`, `nm_prop`, `create_at`, `update_at`) VALUES ('91', 'PAPUA', '2019-03-14 00:27:10', '2019-03-14 00:27:19');


#
# TABLE STRUCTURE FOR: r_rekening
#

DROP TABLE IF EXISTS `r_rekening`;

CREATE TABLE `r_rekening` (
  `rek_id` varchar(10) NOT NULL,
  `bank_id` varchar(10) NOT NULL,
  `no_rek` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`rek_id`),
  KEY `bank_id` (`bank_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_rekening` (`rek_id`, `bank_id`, `no_rek`, `create_at`, `update_at`, `is_aktif`) VALUES ('09', '3', '890', NULL, NULL, '1');
INSERT INTO `r_rekening` (`rek_id`, `bank_id`, `no_rek`, `create_at`, `update_at`, `is_aktif`) VALUES ('123', '10', '321', NULL, NULL, '1');


#
# TABLE STRUCTURE FOR: r_satuan
#

DROP TABLE IF EXISTS `r_satuan`;

CREATE TABLE `r_satuan` (
  `satuan_id` varchar(10) NOT NULL,
  `satuan` varchar(20) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`satuan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_satuan` (`satuan_id`, `satuan`, `create_at`, `update_at`, `is_aktif`) VALUES ('SB01', 'BOTOL', '2019-03-13 23:51:39', NULL, 'Aktif');
INSERT INTO `r_satuan` (`satuan_id`, `satuan`, `create_at`, `update_at`, `is_aktif`) VALUES ('SB02', 'AMP', '2019-03-13 23:51:53', NULL, 'Aktif');
INSERT INTO `r_satuan` (`satuan_id`, `satuan`, `create_at`, `update_at`, `is_aktif`) VALUES ('SB03', 'TUBE', '2019-03-13 23:52:13', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: r_status
#

DROP TABLE IF EXISTS `r_status`;

CREATE TABLE `r_status` (
  `status_id` varchar(10) NOT NULL DEFAULT '0',
  `status` varchar(50) NOT NULL DEFAULT '',
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`status_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `r_status` (`status_id`, `status`, `create_at`, `update_at`) VALUES ('0', 'TUNGGU', NULL, NULL);
INSERT INTO `r_status` (`status_id`, `status`, `create_at`, `update_at`) VALUES ('1', 'DITANGANI', NULL, NULL);
INSERT INTO `r_status` (`status_id`, `status`, `create_at`, `update_at`) VALUES ('2', 'SELESAI', NULL, NULL);
INSERT INTO `r_status` (`status_id`, `status`, `create_at`, `update_at`) VALUES ('3', 'BATAL', NULL, NULL);


#
# TABLE STRUCTURE FOR: r_status_kawin
#

DROP TABLE IF EXISTS `r_status_kawin`;

CREATE TABLE `r_status_kawin` (
  `id_sk` varchar(10) NOT NULL,
  `status_kawin` varchar(30) NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_sk`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `r_status_kawin` (`id_sk`, `status_kawin`, `create_at`, `update_at`, `is_aktif`) VALUES ('01', 'MENIKAH', NULL, '2019-03-14 03:06:02', 'Aktif');
INSERT INTO `r_status_kawin` (`id_sk`, `status_kawin`, `create_at`, `update_at`, `is_aktif`) VALUES ('MN2', 'BELUM MENI', '2019-03-15 00:50:38', NULL, 'Aktif');


#
# TABLE STRUCTURE FOR: t_harga_beli
#

DROP TABLE IF EXISTS `t_harga_beli`;

CREATE TABLE `t_harga_beli` (
  `harga_beli_id` varchar(10) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `kategori_brg_id` varchar(10) DEFAULT NULL,
  `harga_beli` int(10) NOT NULL,
  `tgl_berlaku` date NOT NULL,
  `ket` text NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`harga_beli_id`),
  KEY `barang_id` (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_harga_jual
#

DROP TABLE IF EXISTS `t_harga_jual`;

CREATE TABLE `t_harga_jual` (
  `id` varchar(10) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `kategori_brg_id` varchar(10) DEFAULT NULL,
  `kelas_id` varchar(10) NOT NULL DEFAULT '1',
  `harga_jual` int(10) unsigned NOT NULL DEFAULT '0',
  `tgl_berlaku` date DEFAULT NULL,
  `diskon_persen` decimal(4,1) DEFAULT NULL,
  `diskon_rupiah` int(10) unsigned DEFAULT NULL,
  `ket` varchar(500) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_harga_jual` (`id`, `kode_barang`, `kategori_brg_id`, `kelas_id`, `harga_jual`, `tgl_berlaku`, `diskon_persen`, `diskon_rupiah`, `ket`, `create_at`, `update_at`) VALUES ('123', '1445', 'KTB03', 'KLS01', '23000', '2019-03-27', '0.7', '12', 'nowey', '2019-03-16 02:19:07', '2019-03-16 02:21:57');


#
# TABLE STRUCTURE FOR: t_janji
#

DROP TABLE IF EXISTS `t_janji`;

CREATE TABLE `t_janji` (
  `id` varchar(10) NOT NULL,
  `peaksana_id` varchar(10) DEFAULT NULL,
  `pasien_id` varchar(10) DEFAULT NULL,
  `jenis_kunjungan_id` varchar(10) DEFAULT NULL,
  `tanggal_janji` datetime DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `urut` int(3) DEFAULT NULL,
  `status` varchar(10) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_janji_batal
#

DROP TABLE IF EXISTS `t_janji_batal`;

CREATE TABLE `t_janji_batal` (
  `id` varchar(10) NOT NULL,
  `janji_id` varchar(10) DEFAULT NULL,
  `tanggal_batal` datetime DEFAULT NULL,
  `pembatalan` varchar(20) DEFAULT NULL,
  `alasan` varchar(500) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_penerimaan_rinci
#

DROP TABLE IF EXISTS `t_penerimaan_rinci`;

CREATE TABLE `t_penerimaan_rinci` (
  `kode_penerimaan` varchar(10) NOT NULL,
  `tanggal_penerimaan` datetime NOT NULL,
  `kode_pemasok` varchar(10) NOT NULL,
  `kode_barang` varchar(10) NOT NULL,
  `jumlah` int(6) NOT NULL,
  `ket` text NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kode_penerimaan`),
  KEY `pemasok_id` (`kode_pemasok`),
  KEY `kode_barang` (`kode_barang`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pengeluaran
#

DROP TABLE IF EXISTS `t_pengeluaran`;

CREATE TABLE `t_pengeluaran` (
  `pengeluaran_id` varchar(10) NOT NULL,
  `tanggal_pengeluaran` date NOT NULL,
  `pengeluaran` int(10) NOT NULL,
  `jenis_pengeluaran_id` varchar(10) NOT NULL,
  `ket` text NOT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pengeluaran_id`),
  KEY `jenis_pengeluaran_id` (`jenis_pengeluaran_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_periksa
#

DROP TABLE IF EXISTS `t_periksa`;

CREATE TABLE `t_periksa` (
  `periksa_id` varchar(10) NOT NULL,
  `registrasi_id` varchar(10) DEFAULT NULL,
  `tanggal_periksa` datetime DEFAULT NULL,
  `anamnesa` varchar(500) DEFAULT NULL,
  `diagnosa` varchar(500) DEFAULT NULL,
  `terapi` varchar(500) DEFAULT NULL,
  `tekanan_darah` varchar(10) DEFAULT NULL,
  `tinggi_badan` varchar(5) DEFAULT NULL,
  `berat_badan` varchar(5) DEFAULT NULL,
  `pelaksana_id` varchar(10) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`periksa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_pesan
#

DROP TABLE IF EXISTS `t_pesan`;

CREATE TABLE `t_pesan` (
  `pesan_id` varchar(10) NOT NULL,
  `kode_pesan` varchar(10) DEFAULT NULL,
  `tanggal_pesan` datetime DEFAULT NULL,
  `registrasi_id` varchar(10) DEFAULT NULL,
  `alamat_kirim` varchar(500) DEFAULT NULL,
  `sub_total` int(3) DEFAULT NULL,
  `diskon_persen` decimal(4,0) DEFAULT NULL,
  `diskon_rupiah` decimal(4,0) DEFAULT NULL,
  `grand_total` int(3) DEFAULT NULL,
  `ongkir` int(3) DEFAULT NULL,
  `total` int(3) DEFAULT NULL,
  `s_bayar` int(3) DEFAULT NULL,
  `tanggal_bayar` datetime DEFAULT NULL,
  `kurir_id` varchar(10) DEFAULT NULL,
  `no_resi` varchar(15) DEFAULT NULL,
  `s_kirim` varchar(15) DEFAULT NULL,
  `tanggal_kirim` datetime DEFAULT NULL,
  `tanggal_terima` datetime DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`pesan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_registrasi
#

DROP TABLE IF EXISTS `t_registrasi`;

CREATE TABLE `t_registrasi` (
  `id` varchar(10) NOT NULL,
  `no_registrasi` bigint(12) unsigned NOT NULL,
  `kode_pasien` varchar(10) NOT NULL,
  `tgl_reg` datetime DEFAULT NULL,
  `jumlah_pasien` int(3) unsigned NOT NULL,
  `jenis_kunjungan_id` varchar(10) NOT NULL DEFAULT '1',
  `kelas_id` varchar(10) NOT NULL DEFAULT '1',
  `urut` int(3) unsigned NOT NULL,
  `mulai` datetime NOT NULL,
  `selesai` datetime NOT NULL,
  `status_id` varchar(10) NOT NULL DEFAULT '0',
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stok_opname
#

DROP TABLE IF EXISTS `t_stok_opname`;

CREATE TABLE `t_stok_opname` (
  `id` varchar(10) NOT NULL,
  `kode_stok_opname` varchar(10) DEFAULT NULL,
  `tgl_stok_opname` datetime DEFAULT NULL,
  `ket` varchar(500) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stok_opname_hadiah
#

DROP TABLE IF EXISTS `t_stok_opname_hadiah`;

CREATE TABLE `t_stok_opname_hadiah` (
  `id` varchar(10) NOT NULL,
  `kode_stok_opname` varchar(10) DEFAULT NULL,
  `tanggal_stok_opname` datetime DEFAULT NULL,
  `ket` varchar(500) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stok_opname_hadiah_rinci
#

DROP TABLE IF EXISTS `t_stok_opname_hadiah_rinci`;

CREATE TABLE `t_stok_opname_hadiah_rinci` (
  `id` varchar(10) NOT NULL,
  `stok_opname_id` varchar(10) DEFAULT NULL,
  `urut` int(3) DEFAULT NULL,
  `hadiah_id` varchar(10) DEFAULT NULL,
  `opname_terakhir` date DEFAULT NULL,
  `stok` int(5) DEFAULT NULL,
  `stok_fisik` int(5) DEFAULT NULL,
  `selisih` int(6) DEFAULT NULL,
  `ket` varchar(500) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_stok_opname_rinci
#

DROP TABLE IF EXISTS `t_stok_opname_rinci`;

CREATE TABLE `t_stok_opname_rinci` (
  `id` varchar(10) NOT NULL,
  `stok_opname_id` varchar(10) DEFAULT NULL,
  `urut` int(3) DEFAULT NULL,
  `kode_brg` varchar(10) DEFAULT NULL,
  `opname_terakhir` date DEFAULT NULL,
  `stok` int(5) DEFAULT NULL,
  `stok_fisik` int(5) DEFAULT NULL,
  `selisih` int(5) DEFAULT NULL,
  `ket` varchar(500) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: t_tarif_tindakan
#

DROP TABLE IF EXISTS `t_tarif_tindakan`;

CREATE TABLE `t_tarif_tindakan` (
  `tarif_tindakan_id` varchar(10) NOT NULL,
  `kode_tindakan` varchar(10) NOT NULL,
  `grup_tindakan_id` varchar(10) DEFAULT NULL,
  `kelas_id` varchar(10) NOT NULL,
  `tarif` int(10) NOT NULL,
  `disc_persen` decimal(4,0) NOT NULL,
  `disc_rupiah` int(10) NOT NULL,
  `tgl_berlaku` date NOT NULL,
  `ket` text NOT NULL,
  `is_aktif` varchar(15) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tarif_tindakan_id`),
  KEY `tindakan_id` (`kode_tindakan`),
  KEY `kelas_id` (`kelas_id`),
  KEY `kelas_id_2` (`kelas_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `t_tarif_tindakan` (`tarif_tindakan_id`, `kode_tindakan`, `grup_tindakan_id`, `kelas_id`, `tarif`, `disc_persen`, `disc_rupiah`, `tgl_berlaku`, `ket`, `is_aktif`, `create_at`, `update_at`) VALUES ('1243213', 'TDT02', 'GT1', 'KLS01', '1232', '1232', '1232', '2019-03-22', 'sadfghjgfds', 'Aktif', '2019-03-13 12:05:56', '2019-03-13 12:06:57');
INSERT INTO `t_tarif_tindakan` (`tarif_tindakan_id`, `kode_tindakan`, `grup_tindakan_id`, `kelas_id`, `tarif`, `disc_persen`, `disc_rupiah`, `tgl_berlaku`, `ket`, `is_aktif`, `create_at`, `update_at`) VALUES ('DT009', 'TDT01', 'GT3', 'KLS02', '90000', '43', '78000', '2019-03-23', 'tidak ada', 'Aktif', '2019-03-12 00:59:10', '2019-03-12 01:04:45');


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(15) NOT NULL,
  `nama` varchar(90) DEFAULT NULL,
  `pass` varchar(40) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `create_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_at` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `is_aktif` varchar(15) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('123211', '09', 'c20ad4d76fe97759aa27a0c99bff6710', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('ADMIN', 'ADMIN', 'e10adc3949ba59abbe56e057f20f883e', '1', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('asdsd', 'asdsad', 'b447c27a00e3a348881b0030177000cd', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('haris', 'haris', '202cb962ac59075b964b07152d234b70', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('MuhammadHaris99', 'Haria Ae Ea', 'cc2fd37643fce0b20647ca97cba18000', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('sadsa', 'safsafdfdsf', 'ae65ca6fdbbead5105c0254745371bba', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('USER', 'HARIS', 'd8578edf8458ce06fbc5bb76a58c5ca4', '2', NULL, NULL, '1');
INSERT INTO `user` (`id`, `nama`, `pass`, `level`, `create_at`, `update_at`, `is_aktif`) VALUES ('WESMULAI', 'wes mulai', 'cc2fd37643fce0b20647ca97cba18000', '2', NULL, NULL, '1');


